var searchData=
[
  ['next_0',['next',['../struct_node.html#a772e2a82248c0d0dfc5cdf19d5b45df9',1,'Node::next'],['../fucntions_8c.html#a137cc3644b15b06c5be2496a0d97c402',1,'next:&#160;fucntions.c']]],
  ['node_1',['Node',['../struct_node.html',1,'Node'],['../dlinkedlist_8c.html#a3b09f37e675bcd48a01bf22155996872',1,'Node:&#160;dlinkedlist.c'],['../function_a_a_m_8c.html#a3b09f37e675bcd48a01bf22155996872',1,'Node:&#160;functionAAM.c'],['../function_a_y_8c.html#a3b09f37e675bcd48a01bf22155996872',1,'Node:&#160;functionAY.c']]]
];
