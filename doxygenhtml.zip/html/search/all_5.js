var searchData=
[
  ['insertafter_0',['insertAfter',['../fucntions_8c.html#a954875047d7e3d0c60b0bb534f6ffe31',1,'insertAfter(struct doubleLinkedList *, int newdata):&#160;fucntions.c'],['../function_a_a_m_8c.html#a131e2ee1617d58de00ad7d8acf2c03c6',1,'insertAfter(doubleLinkedList *list, int newdata):&#160;functionAAM.c']]],
  ['insertbeforecur_1',['insertbeforecur',['../dlinkedlist_8c.html#a047a467f88345eb22d7c6fd381de4c8b',1,'dlinkedlist.c']]],
  ['insertbeforecurr_2',['insertbeforecurr',['../function_a_y_8c.html#a2e45c20270bf66f7e90ac2cff605b5e1',1,'functionAY.c']]]
];
