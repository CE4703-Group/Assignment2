var searchData=
[
  ['tail_0',['tail',['../structdouble_linked_list.html#a57b4f7de4a0bb98e7904d9e1b00095f8',1,'doubleLinkedList::tail'],['../structdouble_linked_list.html#afffd80c1232c2f537d90e6603af27853',1,'doubleLinkedList::tail']]]
];
