var searchData=
[
  ['current_0',['current',['../structdouble_linked_list.html#a2c23a7d933499ab95a1a8a77f3214598',1,'doubleLinkedList']]]
];
