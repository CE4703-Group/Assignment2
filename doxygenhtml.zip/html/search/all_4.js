var searchData=
[
  ['head_0',['head',['../structdouble_linked_list.html#a6923e90437caae9a37d739407ee11c62',1,'doubleLinkedList::head'],['../structdouble_linked_list.html#ac651408ccde65ff63e8be68ba756a216',1,'doubleLinkedList::head']]]
];
