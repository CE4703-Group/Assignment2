var searchData=
[
  ['gototail_0',['gotoTail',['../fucntions_8c.html#ad3be9696a4f695d49f9a7bda68e327d1',1,'gotoTail(doubleLinkedList):&#160;fucntions.c'],['../function_a_a_m_8c.html#a0cdd8dd0ebc79aaf1ca638dcb695488e',1,'gotoTail(doubleLinkedList *list):&#160;functionAAM.c']]]
];
