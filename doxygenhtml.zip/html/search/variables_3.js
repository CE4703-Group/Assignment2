var searchData=
[
  ['next_0',['next',['../struct_node.html#a772e2a82248c0d0dfc5cdf19d5b45df9',1,'Node']]]
];
