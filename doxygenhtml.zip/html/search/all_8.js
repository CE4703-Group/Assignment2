var searchData=
[
  ['prev_0',['prev',['../struct_node.html#a4654353865cc2bad9b1a03fd8fb26af8',1,'Node::prev'],['../fucntions_8c.html#a37e814a9f0283663416b7f9836af8f4c',1,'prev:&#160;fucntions.c']]]
];
