var searchData=
[
  ['data_0',['data',['../struct_node.html#a87c003c9f600e3fc58e6e90835f0b605',1,'Node']]]
];
