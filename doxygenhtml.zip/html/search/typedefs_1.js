var searchData=
[
  ['next_0',['next',['../fucntions_8c.html#a137cc3644b15b06c5be2496a0d97c402',1,'fucntions.c']]],
  ['node_1',['Node',['../dlinkedlist_8c.html#a3b09f37e675bcd48a01bf22155996872',1,'Node:&#160;dlinkedlist.c'],['../function_a_a_m_8c.html#a3b09f37e675bcd48a01bf22155996872',1,'Node:&#160;functionAAM.c'],['../function_a_y_8c.html#a3b09f37e675bcd48a01bf22155996872',1,'Node:&#160;functionAY.c']]]
];
